package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.Model.User;
import com.service.UserService;

@Controller
public class Controllers {
	@Autowired
	UserService service;

	@RequestMapping("/")
	public String getDisplay() {
		return "home";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)

	ModelAndView addCustomer(@ModelAttribute("cust") User user, BindingResult result) {
		if (result.hasErrors())
			return new ModelAndView("add", "user", user);
//		service.add(user);
		return new ModelAndView("welcome", "username", user.getUserName());

	}
}
