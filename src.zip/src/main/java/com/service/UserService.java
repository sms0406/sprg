package com.service;

import org.springframework.stereotype.Service;

import com.Model.User;

@Service
public class UserService {
	public void add(User user)
	{
		
	}

}
